import numpy as np
import GPy
import os

def load_baseline(filename):

    # load saved data
    saved=np.load(filename)
    dim=saved['X'].shape[1]

    # create kernel
    k=GPy.kern.StdPeriodic(input_dim=dim,ARD1=False,ARD2=True)

    # create mean function
    mf=GPy.mappings.Constant(dim,1)

    # create model
    m=GPy.models.GPRegression(saved['X'],saved['Y'],kernel=k,mean_function=mf)

    # set model params
    m[:]=saved['params']
    m.fix()
    m.parameters_changed()

    return m

def f(x):

    # choose model to use:

    model=load_baseline('amber_4D.npz')
    
    # prediction:

    prediction=model.predict(np.atleast_2d(x))[0][0][0]
    make_movie(np.atleast_2d(x))        

    os.system('babel -igzmat ala.gzmat -oxyz ala.xyz')
    os.system("sed -i 's/ala.gzmat/E = "+str(prediction)+"/g' ala.xyz")
    os.system('cat ala.xyz >> movie.xyz')
    os.system('rm ala.xyz ala.gzmat')

    return prediction

def make_movie(var):

    gzmat_stub = '''#Put Keywords Here, check Charge and Multiplicity.

 alanine.pdb

0  793068623
C
H  1  r2
N  1  r3  2  a3
H  3  r4  1  a4  2  d4
H  3  r5  1  a5  2  d5
C  1  r6  2  a6  3  d6
H  6  r7  1  a7  2  d7
H  6  r8  1  a8  2  d8
H  6  r9  1  a9  2  d9
C  1  r10  2  a10  3  d10
O  10  r11  1  a11  2  d11
O  10  r12  1  a12  2  d12
H  12  r13  10  a13  1  d13
Variables:
r2= 1.0930
r3= 1.4913
r4= 1.0207
r5= 1.0179
r6= 1.5394
r7= 1.0916
r8= 1.0925
r9= 1.0925
r10= 1.5393
r11= 1.2080
r12= 1.2949
r13= 0.9721
a3= 108.76
a4= 108.69
a5= 108.73
a6= 108.79
a7= 110.43
a8= 110.82
a9= 110.27
a10= 104.84
a11= 125.82
a12= 115.89
a13=  98.39
d6= 240
d10= 120
'''

    # open Z-matrix and write stub
    Zmat = open('ala.gzmat','w')
    Zmat.write(gzmat_stub)
    Zmat.close
    
    Zmat = open('ala.gzmat','a')
    # write derived variables first
    Zmat.write('d5= ' + str(var[0][0]+120) + '\n')
    Zmat.write('d8= ' + str(var[0][1]+120) + '\n')
    Zmat.write('d9= ' + str(var[0][1]+240) + '\n')
    Zmat.write('d12= ' + str(var[0][2]-180) + '\n')

    # write main variables last
    Zmat.write('d4= ' + str(var[0][0]) + '\n')
    Zmat.write('d7= ' + str(var[0][1]) + '\n')
    Zmat.write('d11= ' + str(var[0][2]) + '\n')
    Zmat.write('d13= ' + str(var[0][3]) + '\n')
    Zmat.close











